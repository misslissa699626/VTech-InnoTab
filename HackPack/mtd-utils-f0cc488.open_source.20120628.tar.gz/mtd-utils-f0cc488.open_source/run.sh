#!/bin/sh

make clean
make -C lib clean
make -C ubi-utils clean
make
make -C lib
make -C ubi-utils
arm-none-linux-gnueabi-strip nanddump
arm-none-linux-gnueabi-strip flash_erase
arm-none-linux-gnueabi-strip mtd_debug
arm-none-linux-gnueabi-strip ubi-utils/ubiattach
arm-none-linux-gnueabi-strip ubi-utils/ubiformat
arm-none-linux-gnueabi-strip ubi-utils/ubidetach
arm-none-linux-gnueabi-strip ubi-utils/ubimkvol

