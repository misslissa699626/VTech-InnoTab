/*
 *  nandwrite.c
 *
 *  Copyright (C) 2000 Steven J. Hill (sjhill@realitydiluted.com)
 *		  2003 Thomas Gleixner (tglx@linutronix.de)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * Overview:
 *   This utility writes a binary image directly to a NAND flash
 *   chip or NAND chips contained in DoC devices. This is the
 *   "inverse operation" of nanddump.
 *
 * tglx: Major rewrite to handle bad blocks, write data with or without ECC
 *	 write oob data only on request
 *
 * Bug/ToDo:
 */

#define PROGRAM_NAME "nandwrite"
#define VERSION "$Revision: 1.32 $"

#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <getopt.h>

#include <asm/types.h>
#include "mtd/mtd-user.h"
#include "common.h"
#include <libmtd.h>

#define INNOTAB_DEBUG	2

#if (INNOTAB_DEBUG > 0)
	#define ERR_PRINT(fmt,arg...)		printf( "%s()-%d: "fmt, __PRETTY_FUNCTION__, __LINE__ ,##arg)
	#if (INNOTAB_DEBUG > 1)
		#define DB_PRINT(fmt,arg...)	printf( "%s()-%d: "fmt, __PRETTY_FUNCTION__, __LINE__ ,##arg)
	#else
	 	#define DB_PRINT(fmt,arg...)	
	#endif
#else
 	#define DB_PRINT(fmt,arg...)
 	#define ERR_PRINT(fmt,arg...)
#endif

// oob layouts to pass into the kernel as default
static struct nand_oobinfo none_oobinfo = {
	.useecc = MTD_NANDECC_OFF,
};

static struct nand_oobinfo jffs2_oobinfo = {
	.useecc = MTD_NANDECC_PLACE,
	.eccbytes = 6,
	.eccpos = { 0, 1, 2, 3, 6, 7 }
};

static struct nand_oobinfo yaffs_oobinfo = {
	.useecc = MTD_NANDECC_PLACE,
	.eccbytes = 6,
	.eccpos = { 8, 9, 10, 13, 14, 15}
};

static struct nand_oobinfo autoplace_oobinfo = {
	.useecc = MTD_NANDECC_AUTOPLACE
};

int mtd_write_readback(const struct mtd_dev_info *mtd, int fd, int eb, int offs,
	      void *buf, int len, char *readbackbuf );
int last_good_erase_block_addr( int fd, struct mtd_dev_info *mtd );
int end_marker_found( struct mtd_dev_info *mtd, int fd, int blkaddr, char *readBuf, int sigBlkSize, char *sig );
int write_last_erase_block( int fd, const char *mtd_device, struct mtd_dev_info *mtd, int lastaddr, int firstaddr, libmtd_t *mtd_desc );

static void display_help(void)
{
	printf(
"Usage: nandwrite [OPTION] MTD_DEVICE [INPUTFILE|-]\n"
"Writes to the specified MTD device.\n"
"\n"
"  -a, --autoplace         Use auto oob layout\n"
"  -j, --jffs2             Force jffs2 oob layout (legacy support)\n"
"  -y, --yaffs             Force yaffs oob layout (legacy support)\n"
"  -f, --forcelegacy       Force legacy support on autoplacement-enabled mtd\n"
"                          device\n"
"  -m, --markbad           Mark blocks bad if write fails\n"
"  -n, --noecc             Write without ecc\n"
"  -N, --noskipbad         Write without bad block skipping\n"
"  -o, --oob               Image contains oob data\n"
"  -r, --raw               Image contains the raw oob data dumped by nanddump\n"
"  -s addr, --start=addr   Set start address (default is 0)\n"
"  -p, --pad               Pad to page size\n"
"  -b, --blockalign=1|2|4  Set multiple of eraseblocks to align to\n"
"  -q, --quiet             Don't display progress messages\n"
"      --help              Display this help and exit\n"
"      --version           Output version information and exit\n"
"  -e, --endmark		   Write end marker at last good erase block (InnoTab specific)\n"
"  -v, --verifyonly		   Verify only, no write to NAND\n"
"  -z size, --size=size    Set the expected size of the image to be written to NAND\n"
"  -c  --crazyretry		   Mark bad block and proceed if for any error\n"
	);
	exit(0);
}

static void display_version(void)
{
	/*
	printf("%1$s " VERSION "\n"
			"\n"
			"Copyright (C) 2003 Thomas Gleixner \n"
			"\n"
			"%1$s comes with NO WARRANTY\n"
			"to the extent permitted by law.\n"
			"\n"
			"You may redistribute copies of %1$s\n"
			"under the terms of the GNU General Public Licence.\n"
			"See the file `COPYING' for more information.\n",
			PROGRAM_NAME);
	*/
	printf( "InnoTab Production Tool, nandwrite, version: 1.0\n" );
	exit(0);
}

static const char	*standard_input = "-";
static const char	*mtd_device, *img;
static long long	mtdoffset = 0;
static bool		quiet = false;
static bool		writeoob = false;
static bool		rawoob = false;
static bool		autoplace = false;
static bool		markbad = false;
static bool		forcejffs2 = false;
static bool		forceyaffs = false;
static bool		forcelegacy = false;
static bool		noecc = false;
static bool		noskipbad = false;
static bool		pad = false;
static int		blockalign = 1; /* default to using actual block size */
static int		enable_bbt = 0;
static int		verify_only_mode = 0;
static long long	expected_image_size = -1;
static int		crazyretry_enable = 0;

static void process_options(int argc, char * const argv[])
{
	int error = 0;

	for (;;) {
		int option_index = 0;
		static const char *short_options = "ab:fjmnNopqrs:yevz:c";
		static const struct option long_options[] = {
			{"help", no_argument, 0, 0},
			{"version", no_argument, 0, 0},
			{"autoplace", no_argument, 0, 'a'},
			{"blockalign", required_argument, 0, 'b'},
			{"forcelegacy", no_argument, 0, 'f'},
			{"jffs2", no_argument, 0, 'j'},
			{"markbad", no_argument, 0, 'm'},
			{"noecc", no_argument, 0, 'n'},
			{"noskipbad", no_argument, 0, 'N'},
			{"oob", no_argument, 0, 'o'},
			{"pad", no_argument, 0, 'p'},
			{"quiet", no_argument, 0, 'q'},
			{"raw", no_argument, 0, 'r'},
			{"start", required_argument, 0, 's'},
			{"yaffs", no_argument, 0, 'y'},
			{"endmark", no_argument, 0, 'e'},
			{"verifyonly", no_argument, 0, 'v'},
			{"size", required_argument, 0, 'z'},
			{"crazyretry", no_argument, 0, 'c'},
			{0, 0, 0, 0},
		};

		int c = getopt_long(argc, argv, short_options,
				long_options, &option_index);
		if (c == EOF) {
			break;
		}

		switch (c) {
			case 0:
				switch (option_index) {
					case 0:
						display_help();
						break;
					case 1:
						display_version();
						break;
				}
				break;
			case 'q':
				quiet = true;
				break;
			case 'a':
				autoplace = true;
				break;
			case 'j':
				forcejffs2 = true;
				break;
			case 'y':
				forceyaffs = true;
				break;
			case 'f':
				forcelegacy = true;
				break;
			case 'n':
				noecc = true;
				break;
			case 'N':
				noskipbad = true;
				break;
			case 'm':
				markbad = true;
				break;
			case 'o':
				writeoob = true;
				break;
			case 'p':
				pad = true;
				break;
			case 'r':
				rawoob = true;
				writeoob = true;
				break;
			case 's':
				mtdoffset = simple_strtoll(optarg, &error);
				break;
			case 'b':
				blockalign = atoi(optarg);
				break;
			case 'e':
				enable_bbt = 1;
				break;
			case 'v':
				verify_only_mode = 1;
				break;
			case 'z':
				expected_image_size = simple_strtoll(optarg, &error);
				break;
			case 'c':
				crazyretry_enable = 1;
				break;
			case '?':
				error++;
				break;
		}
	}

	if (mtdoffset < 0)
		errmsg_die("Can't specify negative device offset with option"
				" -s: %lld", mtdoffset);

	if (blockalign < 0)
		errmsg_die("Can't specify negative blockalign with option -b:"
				" %d", blockalign);

	argc -= optind;
	argv += optind;

	/*
	 * There must be at least the MTD device node positional
	 * argument remaining and, optionally, the input file.
	 */

	if (argc < 1 || argc > 2 || error)
		display_help();

	mtd_device = argv[0];

	/*
	 * Standard input may be specified either explictly as "-" or
	 * implicity by simply omitting the second of the two
	 * positional arguments.
	 */

	img = ((argc == 2) ? argv[1] : standard_input);
}

static void erase_buffer(void *buffer, size_t size)
{
	const uint8_t kEraseByte = 0xff;

	if (buffer != NULL && size > 0) {
		memset(buffer, kEraseByte, size);
	}
}

/*
 * Main program
 */
#define MAX_RETRY_CNT		10
#define MAX_MARK_BAD_CNT	4
int main(int argc, char * const argv[])
{
	int cnt = 0;
	int fd = -1;
	int ifd = -1;
	int imglen = 0, pagelen;
	bool baderaseblock = false;
	long long blockstart = -1;
	struct mtd_dev_info mtd;
	long long offs;
	int ret;
	int oobinfochanged = 0;
	struct nand_oobinfo old_oobinfo;
	bool failed = true;
	// contains all the data read from the file so far for the current eraseblock
	unsigned char *filebuf = NULL;
	size_t filebuf_max = 0;
	size_t filebuf_len = 0;
	char *readbackbuf = NULL;
	// points to the current page inside filebuf
	unsigned char *writebuf = NULL;
	// points to the OOB for the current page in filebuf
	unsigned char *oobreadbuf = NULL;
	unsigned char *oobbuf = NULL;
	libmtd_t mtd_desc;
	int ebsize_aligned;
	int lastaddr;
	long long length_data_received = 0;

	int erase_retry = 0, write_retry = 0, mark_bad_retry = 0;
	long long fail_blockstart = -1;

	process_options(argc, argv);

	if (pad && writeoob) {
		fprintf(stderr, "Can't pad when oob data is present.\n");
		exit(1);
	}

	/* Open the device */
	if ((fd = open(mtd_device, O_RDWR)) == -1) {
		perror(mtd_device);
		exit(2);
	}

	mtd_desc = libmtd_open();
	if (!mtd_desc)
		return errmsg("can't initialize libmtd");
	/* Fill in MTD device capability structure */
	if (mtd_get_dev_info(mtd_desc, mtd_device, &mtd) < 0)
		return errmsg("mtd_get_dev_info failed");

	/*
	 * Pretend erasesize is specified number of blocks - to match jffs2
	 *   (virtual) block size
	 * Use this value throughout unless otherwise necessary
	 */
	ebsize_aligned = mtd.eb_size * blockalign;

	if (mtdoffset & (mtd.min_io_size - 1)) {
		fprintf(stderr, "The start address is not page-aligned !\n"
				"The pagesize of this NAND Flash is 0x%x.\n",
				mtd.min_io_size);
		close(fd);
		exit(3);
	}

	if (autoplace) {
		/* Read the current oob info */
		if (ioctl(fd, MEMGETOOBSEL, &old_oobinfo) != 0) {
			perror("MEMGETOOBSEL");
			close(fd);
			exit(4);
		}

		// autoplace ECC ?
		if (old_oobinfo.useecc != MTD_NANDECC_AUTOPLACE) {
			if (ioctl(fd, MEMSETOOBSEL, &autoplace_oobinfo) != 0) {
				perror("MEMSETOOBSEL");
				close(fd);
				exit(5);
			}
			oobinfochanged = 1;
		}
	}

	if (noecc)  {
		ret = ioctl(fd, MTDFILEMODE, MTD_MODE_RAW);
		if (ret == 0) {
			oobinfochanged = 2;
		} else {
			switch (errno) {
			case ENOTTY:
				if (ioctl(fd, MEMGETOOBSEL, &old_oobinfo) != 0) {
					perror("MEMGETOOBSEL");
					close(fd);
					exit(6);
				}
				if (ioctl(fd, MEMSETOOBSEL, &none_oobinfo) != 0) {
					perror("MEMSETOOBSEL");
					close(fd);
					exit(7);
				}
				oobinfochanged = 1;
				break;
			default:
				perror("MTDFILEMODE");
				close(fd);
				exit(8);
			}
		}
	}

	/*
	 * force oob layout for jffs2 or yaffs ?
	 * Legacy support
	 */
	if (forcejffs2 || forceyaffs) {
		struct nand_oobinfo *oobsel = forcejffs2 ? &jffs2_oobinfo : &yaffs_oobinfo;

		if (autoplace) {
			fprintf(stderr, "Autoplacement is not possible for legacy -j/-y options\n");
			goto restoreoob;
		}
		if ((old_oobinfo.useecc == MTD_NANDECC_AUTOPLACE) && !forcelegacy) {
			fprintf(stderr, "Use -f option to enforce legacy placement on autoplacement enabled mtd device\n");
			goto restoreoob;
		}
		if (mtd.oob_size == 8) {
			if (forceyaffs) {
				fprintf(stderr, "YAFSS cannot operate on 256 Byte page size");
				goto restoreoob;
			}
			/* Adjust number of ecc bytes */
			jffs2_oobinfo.eccbytes = 3;
		}

		if (ioctl(fd, MEMSETOOBSEL, oobsel) != 0) {
			perror("MEMSETOOBSEL");
			goto restoreoob;
		}
	}

	/* Determine if we are reading from standard input or from a file. */
	if (strcmp(img, standard_input) == 0) {
		ifd = STDIN_FILENO;
	} else {
		ifd = open(img, O_RDONLY);
	}

	if (ifd == -1) {
		perror(img);
		goto restoreoob;
	}

	pagelen = mtd.min_io_size + ((writeoob) ? mtd.oob_size : 0);

	/*
	 * For the standard input case, the input size is merely an
	 * invariant placeholder and is set to the write page
	 * size. Otherwise, just use the input file size.
	 *
	 * TODO: Add support for the -l,--length=length option (see
	 * previous discussion by Tommi Airikka <tommi.airikka@ericsson.com> at
	 * <http://lists.infradead.org/pipermail/linux-mtd/2008-September/
	 * 022913.html>
	 */

	if (ifd == STDIN_FILENO) {
	    imglen = pagelen;
	} else {
	    imglen = lseek(ifd, 0, SEEK_END);
	    lseek(ifd, 0, SEEK_SET);
	}

	// Check, if file is page-aligned
	if ((!pad) && ((imglen % pagelen) != 0)) {
		fprintf(stderr, "Input file is not page-aligned. Use the padding "
				 "option.\n");
		goto closeall;
	}

	if ( enable_bbt )
		lastaddr = last_good_erase_block_addr( fd, &mtd );
	else
		lastaddr = mtd.size;
	// Check, if length fits into device
	if ( verify_only_mode == 0 )
	{
		if (lastaddr == -1 || (((imglen+pagelen-1) / pagelen) * mtd.min_io_size) > (lastaddr - mtdoffset)) {		// FIXME
		fprintf(stderr, "Image %d bytes, NAND page %d bytes, OOB area %d"
					" bytes, device size %lld bytes, %d bytes for data\n",
					imglen, pagelen, mtd.oob_size, mtd.size, lastaddr );
			fprintf(stderr,"Input file does not fit into device\n");
		goto closeall;
	}
	}
	else
	{
		if (lastaddr == -1)
		{
			fprintf( stderr, "End marker not found\n" );
			goto closeall;
		}
		if ((((imglen+pagelen-1) / pagelen) * mtd.min_io_size) > (lastaddr - mtdoffset)) {		// FIXME
			fprintf(stderr, "Image %d bytes, NAND page %d bytes, OOB area %d"
					" bytes, device size %lld bytes, %d bytes for data\n",
					imglen, pagelen, mtd.oob_size, mtd.size, lastaddr );
			fprintf(stderr,"Input file does not fit into device\n");
			goto closeall;
		}
	}

	/*
	 * Allocate a buffer big enough to contain all the data (OOB included)
	 * for one eraseblock. The order of operations here matters; if ebsize
	 * and pagelen are large enough, then "ebsize_aligned * pagelen" could
	 * overflow a 32-bit data type.
	 */
	filebuf_max = ebsize_aligned / mtd.min_io_size * pagelen;
	filebuf = xmalloc(filebuf_max);
	erase_buffer(filebuf, filebuf_max);

	/* Allocate a buffer large enough for readback test */
	/* $$ FIXME.  Add OOB read-back test */
	readbackbuf = xmalloc(filebuf_max);
	memset( readbackbuf, 0xff, filebuf_max );
	if ( writeoob )
	{
		fprintf(stderr, "*********************************************\n" );
		fprintf(stderr, "Warning: Read back of OOB is not implemented!\n" );
		fprintf(stderr, "*********************************************\n" );
	}

	oobbuf = xmalloc(mtd.oob_size);
	erase_buffer(oobbuf, mtd.oob_size);

	/*
	 * Get data from input and write to the device while there is
	 * still input to read and we are still within the device
	 * bounds. Note that in the case of standard input, the input
	 * length is simply a quasi-boolean flag whose values are page
	 * length or zero.
	 */
	while (((imglen > 0) || (writebuf < (filebuf + filebuf_len)))
		&& (mtdoffset < lastaddr)) {
		/*
		 * New eraseblock, check for bad block(s)
		 * Stay in the loop to be sure that, if mtdoffset changes because
		 * of a bad block, the next block that will be written to
		 * is also checked. Thus, we avoid errors if the block(s) after the
		 * skipped block(s) is also bad (number of blocks depending on
		 * the blockalign).
		 */
		while (blockstart != (mtdoffset & (~ebsize_aligned + 1))) {
			blockstart = mtdoffset & (~ebsize_aligned + 1);
			offs = blockstart;

			// if writebuf == filebuf, we are rewinding so we must not
			// reset the buffer but just replay it
			if (writebuf != filebuf) {
				erase_buffer(filebuf, filebuf_len);
				filebuf_len = 0;
				writebuf = filebuf;
			}

			baderaseblock = false;
			if (!quiet)
			{
				if ( verify_only_mode )
				{
					fprintf(stdout, "Verifying data at block %lld at offset 0x%llx\n",
							blockstart / ebsize_aligned, blockstart);
				}
				else
				{
				fprintf(stdout, "Writing data to block %lld at offset 0x%llx\n",
						 blockstart / ebsize_aligned, blockstart);
				}
			}

			/* Check all the blocks in an erase block for bad blocks */
			if (noskipbad)
				continue;
			do {
				if ((ret = mtd_is_bad(&mtd, fd, offs / ebsize_aligned)) < 0) {
					sys_errmsg("%s: MTD get bad block failed", mtd_device);
					goto closeall;
				} else if (ret == 1) {
					baderaseblock = true;
					if (!quiet)
						fprintf(stderr, "Bad block at %llx, %u block(s) "
								"from %llx will be skipped\n",
								offs, blockalign, blockstart);
				}

				if (baderaseblock) {
					mtdoffset = blockstart + ebsize_aligned;
				}
				offs +=  ebsize_aligned / blockalign;
			} while (offs < blockstart + ebsize_aligned);

		}

		// Read more data from the input if there isn't enough in the buffer
		if ((writebuf + mtd.min_io_size) > (filebuf + filebuf_len)) {
			int readlen = mtd.min_io_size;

			int alreadyread = (filebuf + filebuf_len) - writebuf;
			int tinycnt = alreadyread;

			while (tinycnt < readlen) {
				cnt = read(ifd, writebuf + tinycnt, readlen - tinycnt);
				if (cnt == 0) { // EOF
					break;
				} else if (cnt < 0) {
					perror("File I/O error on input");
					goto closeall;
				}
				length_data_received += ((long long)cnt) & 0xFFFFFFFF;
				tinycnt += cnt;
			}

			/* No padding needed - we are done */
			if (tinycnt == 0) {
				/*
				 * For standard input, set imglen to 0 to signal
				 * the end of the "file". For nonstandard input,
				 * leave it as-is to detect an early EOF.
				 */
				if (ifd == STDIN_FILENO) {
					imglen = 0;
				}
				break;
			}

			/* Padding */
			if (tinycnt < readlen) {
				if (!pad) {
					fprintf(stderr, "Unexpected EOF. Expecting at least "
							"%d more bytes. Use the padding option.\n",
							readlen - tinycnt);
					goto closeall;
				}
				erase_buffer(writebuf + tinycnt, readlen - tinycnt);
			}

			filebuf_len += readlen - alreadyread;
			if (ifd != STDIN_FILENO) {
				imglen -= tinycnt - alreadyread;
			}
			else if (cnt == 0) {
				/* No more bytes - we are done after writing the remaining bytes */
				imglen = 0;
			}
		}

		if (verify_only_mode && writeoob)
		{
			fprintf(stderr, "************************************************\n" );
			fprintf(stderr, "Warning: Verification of OOB is not implemented!\n" );
			fprintf(stderr, "************************************************\n" );
		}
		if (writeoob && !verify_only_mode) {
			oobreadbuf = writebuf + mtd.min_io_size;

			// Read more data for the OOB from the input if there isn't enough in the buffer
			if ((oobreadbuf + mtd.oob_size) > (filebuf + filebuf_len)) {
				int readlen = mtd.oob_size;
				int alreadyread = (filebuf + filebuf_len) - oobreadbuf;
				int tinycnt = alreadyread;

				while (tinycnt < readlen) {
					cnt = read(ifd, oobreadbuf + tinycnt, readlen - tinycnt);
					if (cnt == 0) { // EOF
						break;
					} else if (cnt < 0) {
						perror("File I/O error on input");
						goto closeall;
					}
					tinycnt += cnt;
				}

				if (tinycnt < readlen) {
					fprintf(stderr, "Unexpected EOF. Expecting at least "
							"%d more bytes for OOB\n", readlen - tinycnt);
					goto closeall;
				}

				filebuf_len += readlen - alreadyread;
				if (ifd != STDIN_FILENO) {
					imglen -= tinycnt - alreadyread;
				}
				else if (cnt == 0) {
					/* No more bytes - we are done after writing the remaining bytes */
					imglen = 0;
				}
			}

			if (!noecc) {
				int i, start, len;
				int tags_pos = 0;
				/*
				 * We use autoplacement and have the oobinfo with the autoplacement
				 * information from the kernel available
				 *
				 * Modified to support out of order oobfree segments,
				 * such as the layout used by diskonchip.c
				 */
				if (!oobinfochanged && (old_oobinfo.useecc == MTD_NANDECC_AUTOPLACE)) {
					for (i = 0; old_oobinfo.oobfree[i][1]; i++) {
						/* Set the reserved bytes to 0xff */
						start = old_oobinfo.oobfree[i][0];
						len = old_oobinfo.oobfree[i][1];
						if (rawoob)
							memcpy(oobbuf + start,
									oobreadbuf + start, len);
						else
							memcpy(oobbuf + start,
									oobreadbuf + tags_pos, len);
						tags_pos += len;
					}
				} else {
					/* Set at least the ecc byte positions to 0xff */
					start = old_oobinfo.eccbytes;
					len = mtd.oob_size - start;
					memcpy(oobbuf + start,
							oobreadbuf + start,
							len);
				}
			}
			/* Write OOB data first, as ecc will be placed in there */
			if (mtd_write_oob(mtd_desc, &mtd, fd, mtdoffset,
						mtd.oob_size,
						noecc ? oobreadbuf : oobbuf)) {
				sys_errmsg("%s: MTD writeoob failure", mtd_device);
				goto closeall;
			}
		}

		/* Write out the Page data */
		if (mtd_write_readback(&mtd, fd, mtdoffset / mtd.eb_size, mtdoffset % mtd.eb_size,
					writebuf, mtd.min_io_size, readbackbuf)) {
			int i;

			if (verify_only_mode != 0)
			{
				fprintf( stderr, "%s: MTD verify failure at %llx\n", mtd_device, mtdoffset );
				goto closeall;
			}

			if ( fail_blockstart != blockstart )
			{
				fail_blockstart = blockstart;
				write_retry = 1;
			}
			else
			{
				write_retry ++;
			}
			sys_errmsg( "%s: Write failure for %d times at %llx\n", mtd_device, write_retry, mtdoffset );

			if (errno != EIO && !crazyretry_enable) {
				sys_errmsg("%s: MTD write failure", mtd_device);
				goto closeall;
			}

			/* Must rewind to blockstart if we can */
			writebuf = filebuf;

			fprintf(stderr, "Erasing failed write from %#08llx to %#08llx\n",
				blockstart, blockstart + ebsize_aligned - 1);
			for (i = blockstart; i < blockstart + ebsize_aligned; i += mtd.eb_size) {
				erase_retry = 0;
				while (mtd_erase(mtd_desc, &mtd, fd, i / mtd.eb_size)) {
					int errno_tmp = errno;
					sys_errmsg("%s: MTD Erase failure", mtd_device);
					if (errno_tmp != EIO) {
						goto closeall;
					}
					erase_retry ++;
					if ( erase_retry > MAX_RETRY_CNT )
					{
						sys_errmsg( "%s: Erase failure exceed limit: %d times at %llx\n", mtd_device, erase_retry, mtdoffset );
						goto markbad_logic;
				}
			}
			}

			if ( write_retry > MAX_RETRY_CNT )
			{
				sys_errmsg( "%s: Write Retry exceed limit: %d times at %llx\n", mtd_device, write_retry, mtdoffset );
				goto markbad_logic;
			}
			mtdoffset = blockstart;
			continue;					// Erase success, replay the buffer

markbad_logic:
			if (markbad) {
				fprintf(stderr, "Marking block at %08llx bad\n",
						mtdoffset & (~mtd.eb_size + 1));
				mark_bad_retry = 0;
				while( 1 )
				{
				if (mtd_mark_bad(&mtd, fd, mtdoffset / mtd.eb_size)) {
						mark_bad_retry ++;
						if ( mark_bad_retry > MAX_MARK_BAD_CNT )
						{
							sys_errmsg("%s: MTD Mark bad block failure at %lld after retrying %d times", mtd_device, mtdoffset, mark_bad_retry );
					goto closeall;
				}
						else
						{
							sys_errmsg("%s: Mark bad failure at %lld for %d times. Erase and retry... ", mtd_device, mtdoffset, mark_bad_retry );
							mtd_erase(mtd_desc, &mtd, fd, mtdoffset / mtd.eb_size);
						}
					}
					else
					{
						sys_errmsg( "%s: Mark bad succesful at %lld after retrying %d times.", mtd_device, mtdoffset, mark_bad_retry );
						break;		// Mark bad successful
					}
				}
			}
			mtdoffset = blockstart + ebsize_aligned;

			continue;
		}
		mtdoffset += mtd.min_io_size;
		writebuf += pagelen;
	}

	failed = false;

	DB_PRINT( "mtdoffset=0x%llx\n", mtdoffset );
	if ( expected_image_size != -1 && length_data_received < expected_image_size )
	{
		ERR_PRINT( "Too few data.  Expected: %lld  Actual: %lld\n", expected_image_size, length_data_received );
		failed = true;
	}
	else if ( enable_bbt && write_last_erase_block( fd, mtd_device, &mtd, lastaddr, (((int)mtdoffset + mtd.eb_size - 1)/mtd.eb_size) * mtd.eb_size, &mtd_desc ) )
		failed = true;

closeall:
	close(ifd);

restoreoob:
	libmtd_close(mtd_desc);
	free(filebuf);
	free(oobbuf);

	if (oobinfochanged == 1) {
		if (ioctl(fd, MEMSETOOBSEL, &old_oobinfo) != 0) {
			perror("MEMSETOOBSEL");
			close(fd);
			exit(9);
		}
	}

	close(fd);

	if (failed
		|| ((ifd != STDIN_FILENO) && (imglen > 0))
		|| (writebuf < (filebuf + filebuf_len))) {
		if ( verify_only_mode )
		{
			//perror("Wrong data detected\n");
			fprintf(stderr, "Wrong data detected\n");
		}
		else
		{
			fprintf(stderr,"Data was only partially written due to error\n");
		}
		exit(10);
	}

	/* Return happy */
	if ( verify_only_mode )
	{
		printf( "Data on NAND flash OK.\n" );
	}
	else
	{
		printf( "Data written to NAND flash completely.\n" );
	}
	return 0;
}

// The caller MUST ensure that enough memory is allocated to readbackbuf
int mtd_write_readback(const struct mtd_dev_info *mtd, int fd, int eb, int offs,
	      void *buf, int len, char *readbackbuf )
{
	int ret = 0;

	if ( verify_only_mode == 0 )
	{
		ret = mtd_write(mtd, fd, eb, offs, buf, len);
		if ( ret )
		{
			fprintf( stderr, "%s() - %d: mtd_write() error: %d\n", __FUNCTION__, __LINE__, errno );
			return ret;
		}
	}

	ret = mtd_read( mtd, fd, eb, offs, readbackbuf, len);
	if ( ret )
	{
		fprintf( stderr, "%s() - %d: mtd_read() error: %d\n", __FUNCTION__, __LINE__, errno );
		return ret;
	}

	if ( memcmp( readbackbuf, buf, len ) )
	{
		fprintf( stderr, "%s() - %d: readback data error: %d\n", __FUNCTION__, __LINE__, errno );
		return -1;
	}

	return 0;
}


#define BBT_REGION_SIZE( device_size )				((device_size)/8)			//Bad block table must be within the last 1/8 of the device
#define MTD_BBT_BLOCK_SIZE							512
#define MTD_SIG_LEN									16
#define MTD_SKIP_END_MARKER_OFF						(MTD_SIG_LEN)
#define MTD_HAVE_BBT_OFF							(MTD_SKIP_END_MARKER_OFF+1)
#define MTD_LAST_PARA_OFF							(MTD_HAVE_BBT_OFF)					// Currently the last item is the "have BBT" attribute
#define BBT_IN_SINLE_EB								1

static char gInnoTabBBTSig[MTD_SIG_LEN]	= { 'I', 'n', 'n', 'o', 'T', 'a', 'b', ' ', 'B', 'B', 'T', 0, 0, 0, 0, 0 };			// Signature for the BBT (bad block table)
int last_good_erase_block_addr( int fd, struct mtd_dev_info *mtd )
{
	int firstBBTBlkAddr, lastBBTBlkAddr, blkaddr;
	char *nandbuf;				// Illegal value
	int last_valid_blk_addr = -1;

	if ( MTD_BBT_BLOCK_SIZE >= mtd->eb_size )			// Should not occur except for program bug
		return last_valid_blk_addr;

	lastBBTBlkAddr = ((unsigned int)mtd->size) - mtd->eb_size;
	firstBBTBlkAddr = ((unsigned int)mtd->size)
						- ( ( BBT_REGION_SIZE((unsigned int)mtd->size) + mtd->eb_size - 1 ) / mtd->eb_size ) * mtd->eb_size;

	nandbuf = xmalloc(mtd->eb_size);

	for ( blkaddr = lastBBTBlkAddr; blkaddr >= firstBBTBlkAddr; blkaddr -= mtd->eb_size ) {
		int ret;

		ret = mtd_is_bad( mtd, fd, blkaddr / mtd->eb_size );
		if ( ret > 0 )
		{
#ifdef PRINT_BAD_BLOCK_WARNING_RESCAN
			ERR_PRINT( "Bad eraseblock at 0x%08x during BBT scan\n", (unsigned int) blkaddr);
#endif
			continue;
		}
		else if ( ret < 0 )
		{
			break;
}

		ret = end_marker_found( mtd, fd, blkaddr, nandbuf, MTD_BBT_BLOCK_SIZE, gInnoTabBBTSig );
		if ( ( ret != -1 && ret != 1 && verify_only_mode == 0 ) || 
			 ( ret != -1 && ret != 0 && verify_only_mode == 1 ) )
			last_valid_blk_addr = blkaddr;
		
		break;
	}

	free( nandbuf );
	return last_valid_blk_addr;
}

int end_marker_found( struct mtd_dev_info *mtd, int fd, int blkaddr, char *readBuf, int sigBlkSize, char *sig )
{
	if ( MTD_BBT_BLOCK_SIZE < MTD_SIG_LEN + 4 )			// Integrity check: always have room for signature + crc
	{
		ERR_PRINT( "MTD_BBT_BLOCK_SIZE too small to accomodate signature + crc\n" );
		return -1;
	}

	if ( sizeof(int) != 4 )
	{
		ERR_PRINT( "Current code is developed based on the assumption of 32-bit integer.\n" );
		return -1;
	}

	if ( sigBlkSize != MTD_BBT_BLOCK_SIZE )
	{
		ERR_PRINT( "readBuf suspicious.  May be program bug.\n" );
		return -1;
	}

	if ( mtd_read( mtd, fd, blkaddr / mtd->eb_size, 0, readBuf, mtd->eb_size ) )
	{
		ERR_PRINT( "Whole erase block read error at: %x\n", blkaddr );
		return -1;
	}

	if ( memcmp( sig, readBuf + mtd->eb_size - MTD_BBT_BLOCK_SIZE, MTD_SIG_LEN ) )
	{
		return 0;
	}

	// The signature at the beginning found.
	return 1;
}

int write_last_erase_block( int fd, const char *mtd_device, struct mtd_dev_info *mtd, int lastaddr, int firstaddr, libmtd_t *mtd_desc )
{
	int firstBBTBlkAddr, lastBBTBlkAddr, blkaddr, err = -1;
	char *nandbuf, *nandbuf_rb;				// Illegal value
	int crc32_val;
	

	if ( MTD_BBT_BLOCK_SIZE >= mtd->eb_size )			// Should not happen except for bug
		return err;

	lastBBTBlkAddr = lastaddr;
	firstBBTBlkAddr = ((unsigned int)mtd->size)
						- ( ( BBT_REGION_SIZE((unsigned int)mtd->size) + mtd->eb_size - 1 ) / mtd->eb_size ) * mtd->eb_size;
	if ( firstaddr > firstBBTBlkAddr )
		firstBBTBlkAddr = firstaddr;

	nandbuf = xmalloc(mtd->eb_size);
	memset(nandbuf, 0x00, mtd->eb_size);
	memcpy(nandbuf + mtd->eb_size - MTD_BBT_BLOCK_SIZE, gInnoTabBBTSig, MTD_SIG_LEN);
	crc32_val = 0x32d3c7bc;								// A hard-coded CRC value for the signature + zero for everything else
	*((int*)&nandbuf[mtd->eb_size-4]) = crc32_val;

	nandbuf_rb = xmalloc(mtd->eb_size);

	if ( ( ( mtd->eb_size / sizeof( int ) ) * sizeof( int ) ) - MTD_BBT_BLOCK_SIZE >= (mtd->size/mtd->eb_size) * sizeof(int) )
	{	// For the moment, only handle the case where the whole BBT fits into the last erase block.
		int i, num_eb, addr, *nand_bbt;
		int accNumOfBadBlock = 0, accNumOfGoodBlock = 0;

		num_eb = mtd->size/mtd->eb_size;
		nand_bbt = xmalloc(num_eb*sizeof(int));
		memset( nand_bbt, -1, num_eb*sizeof(int) );
		for ( addr = i = 0; i < num_eb && addr < firstBBTBlkAddr; i ++, addr += mtd->eb_size )
		{
			int ret;
		
			ret = mtd_is_bad( mtd, fd, i );
			if ( ret < 0 )
			{
				free( nand_bbt );
				free( nandbuf_rb );
				return err;
			}
			else
			{
				if ( ret > 0 )
				{
					accNumOfBadBlock ++;			// For debug only, should not use this value in core-logic
					ERR_PRINT ( "Bad eraseblock %d at 0x%08x\n", i, (unsigned int) addr);
				}
				else
				{
					nand_bbt[accNumOfGoodBlock] = i;
					//printf( "%s() - %d: nand_bbt[%d]=%d\n",  __PRETTY_FUNCTION__, __LINE__, accNumOfGoodBlock, nand_bbt[accNumOfGoodBlock] );
					accNumOfGoodBlock ++;
				}
			}
		}

		//printf( "%s() - %d: num_eb[%d]\n", __PRETTY_FUNCTION__, __LINE__, num_eb );

		memcpy(nandbuf + mtd->eb_size - MTD_BBT_BLOCK_SIZE - num_eb * sizeof(int), nand_bbt, num_eb * sizeof(int) );
		free( nand_bbt );
		// Need to update the CRC signature...
		*((int*)&nandbuf[mtd->eb_size-4]) = 0xf0d818bb;
		nandbuf[mtd->eb_size-MTD_BBT_BLOCK_SIZE+MTD_HAVE_BBT_OFF]=BBT_IN_SINLE_EB;
	}

	for ( blkaddr = lastBBTBlkAddr; blkaddr >= firstBBTBlkAddr; blkaddr -= mtd->eb_size ) {
		int ret;

		ret = mtd_is_bad( mtd, fd, blkaddr / mtd->eb_size );
		if ( ret > 0 )
		{
#ifdef PRINT_BAD_BLOCK_WARNING_RESCAN
			ERR_PRINT( "Bad eraseblock at 0x%08x during BBT scan\n", (unsigned int) blkaddr);
#endif
			continue;
		}
		else if ( ret < 0 )
		{
			break;
		}

		ret = mtd_write_readback( mtd, fd, blkaddr / mtd->eb_size, 0, nandbuf, mtd->eb_size, nandbuf_rb );
		if ( ret )
		{
			if ( verify_only_mode )
			{
				break;
			}

			mtd_erase(mtd_desc, mtd, fd, blkaddr / mtd->eb_size);
			if ( blkaddr - mtd->eb_size >= firstBBTBlkAddr )
			{
				int mark_bad_retry;

				ret = end_marker_found( mtd, fd, blkaddr - mtd->eb_size, nandbuf_rb, MTD_BBT_BLOCK_SIZE, gInnoTabBBTSig );
				if ( ret == -1 || ret == 1 )
				{
					break;
				}

				// Mark the block bad and proceed. Will try to write end-marker at the previous block at next iteration
				mark_bad_retry = 0;
				while( 1 )
				{
					ret = mtd_mark_bad( mtd, fd, blkaddr / mtd->eb_size);
					if ( ret ) 
					{
						mark_bad_retry ++;
						if ( mark_bad_retry > MAX_MARK_BAD_CNT )
						{
							sys_errmsg("%s: MTD Mark bad block failure while writing end-marker at %d after retrying %d times", mtd_device, blkaddr, mark_bad_retry );
							break;
						}
						else
						{
							sys_errmsg("%s: Mark bad failure while writing end-marker at %d for %d times. Erase and retry... ", mtd_device, blkaddr, mark_bad_retry );
							mtd_erase(mtd_desc, mtd, fd, blkaddr / mtd->eb_size);
						}
					}
					else
					{
						sys_errmsg( "%s: Mark bad succesful while writing end-marker at %d after retrying %d times.", mtd_device, blkaddr, mark_bad_retry );
						break;		// Mark bad successful
					}
				}

				if ( ret )
					break;
			}
		}
		else
		{
			err = 0;
			break;
		}
	}

	free( nandbuf );
	free( nandbuf_rb );
	if ( err )
	{
		if ( verify_only_mode )
		{
			ERR_PRINT( "End mark verify failed.\n" );
		}
		else
		{
			ERR_PRINT( "End mark write failed.\n" );
		}
	}
	else
	{
		if ( verify_only_mode )
		{
			DB_PRINT( "End mark verify success: 0x%x\n", blkaddr );
		}
		else
		{
			DB_PRINT( "End mark write success: 0x%x\n", blkaddr );
		}
	}
	return err;
}

